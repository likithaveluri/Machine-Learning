from pyexpat import ErrorString
import numpy as np
import math
import matplotlib.pyplot as plt


def clean_data(line):
    return line.replace('(', '').replace(')', '').replace(' ', '').strip().split(',')


def fetch_data(filename):
    with open(filename, 'r') as f:
        input_data = f.readlines()
        clean_input = list(map(clean_data, input_data))
        f.close()
    return clean_input


def readFile(dataset_path):
    input_data = fetch_data(dataset_path)
    input_np = np.array(input_data)
    return input_np


def weighted_matrix(curr, X_temp): 

	# Tau for definfing the locality
	tau = 0.204

	# Initializing an identity matrix
	W = np.mat(np.eye(X_temp.shape[0]))

	# Denominator in the weighted average function
	denom = (-2 * tau * tau)

	# calculating the corresponding weights for a point
	for i in range(X_temp.shape[0]):
		W[i,i] = np.exp(np.dot((X_temp[i]-curr), (X_temp[i]-curr).T)/denom)
	
	return W


def locallyWeightedLinearRegression():
	Y_pred = np.zeros(y_test.shape[0])
	errors = []
	for pointer in range(X_test.shape[0]):

		# data (X + 1)
		X_temp = np.append(X_train.reshape(X_train.shape[0],1), np.ones(X_train.shape[0]).reshape(X_train.shape[0],1), axis=1)

		# Current datapoint from the test set 
		curr = np.array([X_test[pointer], 1])

		# Updating the values for weighted matrix 
		W = weighted_matrix(curr, X_temp)

		# Calculating for theta
		theta = np.linalg.pinv(X_temp.T*(W * X_temp))*(X_temp.T*(W * y_train.reshape(y_train.shape[0],1)))

		# applying regression for prediction
		pred = np.dot(curr, theta)
		Y_pred[pointer] = pred

		#print(y[pointer], Y_pred[pointer])

		# Error calculation
		error = (Y_pred[pointer] - y_test[pointer]) ** 2
		errors.append(error)
	
	print("Error obtained on test set: ", round(np.mean(errors), 4))

	
	# Plot for training datapoints and the locally weighted regression function
	X_gen = np.linspace(-4, 4, y_test.shape[0]) 
	Y_gen = np.zeros(X_gen.shape[0])
	for pointer in range(X_gen.shape[0]):
		X_temp = np.append(X_gen.reshape(X_gen.shape[0],1), np.ones(X_gen.shape[0]).reshape(X_gen.shape[0],1), axis=1)
		curr = np.array([X_gen[pointer], 1])
		W = weighted_matrix(curr, X_temp)
		theta = np.linalg.pinv(X_temp.T*(W * X_temp))*(X_temp.T*(W * y_test.reshape(y_test.shape[0],1)))
		pred = np.dot(curr, theta)
		Y_gen[pointer] = pred

	plt.scatter(X_test, y_test)
	plt.plot(X_gen, Y_gen)
	plt.title('Graph of the function [Error: ' + str(np.mean(errors)) + '] on test set')
	plt.legend(loc='upper left')
	plt.grid()
	plt.show()
	plt.savefig("Q2_CFunctionGraphWithError.pdf")
	


def main():
	print('START Q2_C\n')
	'''
	Start writing your code here
	'''
	locallyWeightedLinearRegression()
	print('END Q2_C\n')


training_file = './datasets/Q1_B_train.txt'
test_file = './datasets/Q1_C_test.txt'
training_data = readFile(training_file)
test_data = readFile(test_file)
# Inputs of train:
X_train = np.asarray([item[0] for item in training_data], dtype=float)
# Inputs of test
X_test = np.asarray([item[0] for item in test_data], dtype=float)

# Targets of train
y_train= np.asarray([item[1] for item in training_data], dtype=float)
# Targets of test
y_test= np.asarray([item[1] for item in test_data], dtype=float)

assert X_train.shape==y_train.shape, "Shapes of Inputs and Targets on training set are not matching..." 
assert X_test.shape==y_test.shape, "Shapes of Inputs and Targets on test set are not matching..." 


if __name__ == "__main__":
    main()
    