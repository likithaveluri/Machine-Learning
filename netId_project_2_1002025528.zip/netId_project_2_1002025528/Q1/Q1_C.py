import numpy as np
import math
import matplotlib.pyplot as plt

def clean_data(line):
    return line.replace('(', '').replace(')', '').replace(' ', '').strip().split(',')


def fetch_data(filename):
    with open(filename, 'r') as f:
        input_data = f.readlines()
        clean_input = list(map(clean_data, input_data))
        f.close()
    return clean_input


def readFile(dataset_path):
    input_data = fetch_data(dataset_path)
    input_np = np.array(input_data)
    return input_np


def linearRegressionOnTestDP(K=10, D=6):
	'''
	Function with configurable K and D values
	'''
	fig, ax = plt.subplots(K,D+1, figsize=(60, 40))
	iterations=200
	L = 0.01
	n = X_train.shape[0]
	trainErrorMatrix = np.zeros((K,D+1))
	testErrorMatrix = np.zeros((K,D+1))
	coefficientsMatrix = np.zeros((K,D+1), dtype=object)
	for k in range(1,K+1):
		for d in range(D+1):
			X1, Y1 = [], []
			val = -3
			increment = 0.1
			theta = np.zeros(d+1)
			Y_train_pred = np.zeros(y_train.shape[0])
			Y_test_pred = np.zeros(y_test.shape[0])
			for _ in range(61):
				val += increment
				val = round(val, 2)
				X1.append(val)

			for _ in range(iterations):
				for pointer in range(X_train.shape[0]):
					nonLinerEq, a0 = 0, 1
					for i in range(d+1):
						nonLinerEq += theta[i] * (math.sin(k * i * X_train[pointer]) * math.sin(k * i * X_train[pointer]))
					Y_train_pred[pointer] = a0 + nonLinerEq

				# Applying Gradient descent
				D_a0 = (-2/n) * sum(y_train - Y_train_pred)
				a0 = a0 - L * D_a0
				for j in range(len(theta)):
					D_theta = (-2/n) * sum(X_train * (y_train - Y_train_pred))
					theta[j] = theta[j] - L * D_theta

			# Compute mean squared error on test data
			for pointer in range(X_test.shape[0]):
				nonLinerEqTest = 0
				for i in range(d+1):
					nonLinerEqTest += theta[i] * (math.sin(k * i * X_test[pointer]) * math.sin(k * i * X_test[pointer]))
				Y_test_pred[pointer] = a0 + nonLinerEqTest

			testErrorMatrix[k-1][d] = round(np.square(y_test-Y_test_pred).mean(), 3)
			print("k: " + str(k) + ", d: " + str(d) + ' Test error: ' + str(testErrorMatrix[k-1][d]))
		
			for x1 in X1:
				nonLinerEq = 0
				for i in range(d+1):
					nonLinerEq += theta[i] * (math.sin(k * i * x1) * math.sin(k * i * x1))
				Y1.append(a0 + nonLinerEq)


			# Plot trigometric functions for 'k' and 'd' values
			ax[k-1][d].scatter(X_test, y_test, color = '#88c999')
			ax[k-1][d].plot(X1, Y1, '-o', label='function')
			ax[k-1][d].set_title('[k=' + str(k) + ', d=' + str(d) + ' Train error: ' + str(testErrorMatrix[k-1][d]) + ' ]')
			ax[k-1][d].legend(loc='upper left')
			ax[k-1][d].grid()
			
	k_best = np.where(testErrorMatrix==np.amin(testErrorMatrix))[0][0]+1
	d_best = np.where(testErrorMatrix==np.amin(testErrorMatrix))[1][0]
	print("Least Test Error: ", np.amin(testErrorMatrix))
	print("Least Test Error occurred when 'k': ", str(k_best) + ' d: ' + str(d_best))

	# Plot sine functions for various 'd' and 'k' values
	fig.suptitle("Graph of Sine function [Least Test Error " + str(np.amin(testErrorMatrix)) + " occurred when d=" + str(np.where(testErrorMatrix==np.amin(testErrorMatrix))[1][0]) + ", k=" + str(np.where(testErrorMatrix==np.amin(testErrorMatrix))[0][0]+1) + ']', fontsize=35)
	plt.savefig("Q1C_SinePlots.pdf") 



def main():
	print('START Q1_C\n')
	'''
	Start writing your code here
	'''
	linearRegressionOnTestDP()
	print('END Q1_C\n')


training_file = './datasets/Q1_B_train.txt'
test_file = './datasets/Q1_C_test.txt'
data_train = readFile(training_file)
data_test = readFile(test_file)

# Train Inputs:
X_train = np.asarray([item[0] for item in data_train], dtype=float)
# Train Targets
y_train = np.asarray([item[1] for item in data_train], dtype=float)

# Test Inputs:
X_test = np.asarray([item[0] for item in data_test], dtype=float)
# Test Targets
y_test = np.asarray([item[1] for item in data_test], dtype=float)

assert X_train.shape==y_train.shape, "Shapes of Train Inputs and Train Targets are not matching..." 
assert X_test.shape==y_test.shape, "Shapes of Test Inputs and Test Targets are not matching..." 

if __name__ == "__main__":
    main()
    