import numpy as np
import math
import matplotlib.pyplot as plt

def clean_data(line):
    return line.replace('(', '').replace(')', '').replace(' ', '').strip().split(',')


def fetch_data(filename):
    with open(filename, 'r') as f:
        input_data = f.readlines()
        clean_input = list(map(clean_data, input_data))
        f.close()
    return clean_input


def readFile(dataset_path):
    input_data = fetch_data(dataset_path)
    input_np = np.array(input_data)
    return input_np


def linearRegression(K=10, D=6):
	'''
	Function with configurable K and D values
	'''
	fig, ax = plt.subplots(K,D+1, figsize=(60, 40))
	iterations=200
	L = 0.01
	n = X.shape[0]
	errorMatrix = np.zeros((K,D+1))
	coefficientsMatrix = np.zeros((K,D+1), dtype=object)
	for k in range(1,K+1):
		for d in range(D+1):
			X1, Y1 = [], []
			val = -3
			increment = 0.1
			theta = np.zeros(d+1)
			Y_pred = np.zeros(y.shape[0])
			for _ in range(61):
				val += increment
				val = round(val, 2)
				X1.append(val)

			for _ in range(iterations):
				for pointer in range(X.shape[0]):
					nonLinerEq, a0 = 0, 1
					for i in range(d+1):
						nonLinerEq += theta[i] * (math.sin(k * i * X[pointer]) * math.sin(k * i * X[pointer]))
					Y_pred[pointer] = a0 + nonLinerEq

				# Applying Gradient descent
				D_a0 = (-2/n) * sum(y - Y_pred)
				a0 = a0 - L * D_a0
				for j in range(len(theta)):
					D_theta = (-2/n) * sum(X * (y - Y_pred))
					theta[j] = theta[j] - L * D_theta
			print("k: " + str(k) + ", d: " + str(d) + ' Train error: ' + str(round(np.square(y-Y_pred).mean(), 3)))
		
			for x1 in X1:
				nonLinerEq = 0
				for i in range(d+1):
					nonLinerEq += theta[i] * (math.sin(k * i * x1) * math.sin(k * i * x1))
				Y1.append(a0 + nonLinerEq)

			# Save all mean squared error at every 'k' and 'd' values
			errorMatrix[k-1][d] = round(np.square(y-Y_pred).mean(), 3)

			# Save all co-efficients in the coefficientsMatrix
			coefficientsMatrix[k-1][d] = [a0] + list(theta)

			# Plot trigometric functions for 'k' and 'd' values
			ax[k-1][d].scatter(X, y, color = '#88c999')
			ax[k-1][d].plot(X1, Y1, '-o', label='function')
			ax[k-1][d].set_title('[k=' + str(k) + ', d=' + str(d) + ' Train error: ' + str(errorMatrix[k-1][d]) + ' ]')
			ax[k-1][d].legend(loc='upper left')
			ax[k-1][d].grid()
			
	k_best = np.where(errorMatrix==np.amin(errorMatrix))[0][0]+1
	d_best = np.where(errorMatrix==np.amin(errorMatrix))[1][0]
	print("Least Training Error: ", np.amin(errorMatrix))
	print("Least Training Error occurred when 'k': ", str(k_best) + ' d: ' + str(d_best))
	print("Best coefficients: ", coefficientsMatrix[k_best-1][d_best])

	# Plot sine functions for various 'd' and 'k' values
	fig.suptitle("Graph of Sine function [Least Training Error " + str(np.amin(errorMatrix)) + " occurred when d=" + str(np.where(errorMatrix==np.amin(errorMatrix))[1][0]) + ", k=" + str(np.where(errorMatrix==np.amin(errorMatrix))[0][0]+1) + ']', fontsize=35)
	plt.savefig("Q1AB_SinePlots.pdf") 

	
def main():
	print('START Q1_AB\n')
	'''
	Start writing your code here
	'''
	linearRegression()
	print('END Q1_AB\n')


loading_file = './datasets/Q1_B_train.txt'
data = readFile(loading_file)
# Inputs:
X = np.asarray([item[0] for item in data], dtype=float)
# Targets
y = np.asarray([item[1] for item in data], dtype=float)
assert X.shape==y.shape, "Shapes of Inputs and Targets are not matching..." 


if __name__ == "__main__":
    main()