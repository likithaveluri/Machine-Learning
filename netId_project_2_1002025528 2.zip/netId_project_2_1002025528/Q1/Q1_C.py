import numpy as np
import math
import matplotlib.pyplot as plt

# Removing "," and "(", ")" characters from the dataset
def clean_data(line):
    return line.replace('(', '').replace(')', '').replace(' ', '').strip().split(',')


# Retrieve data from the file
def fetch_data(filename):
    with open(filename, 'r') as f:
        input_data = f.readlines()
        clean_input = list(map(clean_data, input_data))
        f.close()
    return clean_input


# Reading file as a numpy array
def readFile(dataset_path):
    input_data = fetch_data(dataset_path)
    input_np = np.array(input_data)
    return input_np


def linearRegressionOnTestDP(K=10, D=6):
	'''
	Function with configurable K and D values
	'''
	# fig, ax = plt.subplots(K,D+1, figsize=(60, 40))  ## Use incase of generating subplots

	# Defining the number of iterations.
	iterations=200

	# Learning rate.
	L = 0.01

	# Number of Input samples in the dataset.
	n = X_train.shape[0]

	# Storing computed errors in the Matrix.
	testErrorMatrix = np.zeros((K,D+1))

	# Stroring the computer Coefficients for the trignometric function in the Matrix.
	coefficientsMatrix = np.zeros((K,D+1), dtype=object)

	# Iterate on 'K' values ranging from 1 to 10.
	for k in range(1,K+1):

		print("For K = " + str(k))
		# Iterate on 'D' values ranging from 0 to 6.
		for d in range(D+1):
			X1, Y1 = [], []
			val = -3
			increment = 0.1

			# Place holder to store co-efficients Theta in linear regression.
			theta = np.zeros(d+1)

			# Place holder to store the predictions in linear regression.
			Y_train_pred = np.zeros(y_train.shape[0])
			Y_test_pred = np.zeros(y_test.shape[0])
			for _ in range(61):
				val += increment
				val = round(val, 2)
				X1.append(val)

			# Regression model training.
			for _ in range(iterations):
				#for pointer in range(X_train.shape[0]):
				pointer = 0
				while(pointer<X_train.shape[0]):

					# Defining place holder for the function and the constant
					nonLinerEq, a0 = 0, 1

					# Iterate over 'd' values to generate the function based on 'd' values.
					i=0
					while(i<d+1):
						nonLinerEq += theta[i] * (math.sin(k * i * X_train[pointer]) * math.sin(k * i * X_train[pointer]))
						i+=1

					
					# Predction
					Y_train_pred[pointer] = a0 + nonLinerEq
					pointer+=1

				# Applying Gradient descent
				D_a0 = (-2/n) * sum(y_train - Y_train_pred)
				a0 = a0 - L * D_a0

				# Updating Theta values 
				j = 0
				while(j<len(theta)):
					D_theta = (-2/n) * sum(X_train * (y_train - Y_train_pred))
					theta[j] = theta[j] - L * D_theta
					j+=1


			# Compute mean squared error on test data

			pointer = 0
			while(pointer<X_test.shape[0]):
				nonLinerEqTest = 0
				
				i=0 
				while(i<d+1):
					nonLinerEqTest += theta[i] * (math.sin(k * i * X_test[pointer]) * math.sin(k * i * X_test[pointer]))
					i+=1

				# Save all test predictions
				Y_test_pred[pointer] = a0 + nonLinerEqTest
				pointer+=1

			testErrorMatrix[k-1][d] = round(np.square(y_test-Y_test_pred).mean(), 3)
			print("For d = " + str(d) + ' MSE = ' + str(testErrorMatrix[k-1][d]))
		
			X1_len = len(X1)
			x1 = 0
			while(x1<X1_len):
				nonLinerEq = 0

				for i in range(d+1):
					nonLinerEq += theta[i] * (math.sin(k * i * X1[x1]) * math.sin(k * i * X1[x1]))
				Y1.append(a0 + nonLinerEq)
				x1+=1


			# Use incase of generating subplots
			# Plot trigometric functions for 'k' and 'd' values as subplots.
			# Uncomment if subplots are required.
			'''
			ax[k-1][d].scatter(X_test, y_test, color = '#88c999')
			ax[k-1][d].plot(X1, Y1, '-o', label='function')
			ax[k-1][d].set_title('[k=' + str(k) + ', d=' + str(d) + ' Train error: ' + str(testErrorMatrix[k-1][d]) + ' ]')
			ax[k-1][d].legend(loc='upper left')
			ax[k-1][d].grid()
			'''

	k_best = np.where(testErrorMatrix==np.amin(testErrorMatrix))[0][0]+1
	d_best = np.where(testErrorMatrix==np.amin(testErrorMatrix))[1][0]
	# print("Least Test Error: ", np.amin(testErrorMatrix))
	# print("Least Test Error occurred when 'k': ", str(k_best) + ' d: ' + str(d_best))

	# Plot sine functions for various 'd' and 'k' values
	# Use incase of generating subplots
	# fig.suptitle("Graph of Sine function [Least Test Error " + str(np.amin(testErrorMatrix)) + " occurred when d=" + str(np.where(testErrorMatrix==np.amin(testErrorMatrix))[1][0]) + ", k=" + str(np.where(testErrorMatrix==np.amin(testErrorMatrix))[0][0]+1) + ']', fontsize=35)
	# plt.savefig("Q1C_SinePlots.pdf") 



def main():
	print('START Q1_C\n')
	'''
	Start writing your code here
	'''
	linearRegressionOnTestDP()
	print('END Q1_C\n')


training_file = './datasets/Q1_B_train.txt'
test_file = './datasets/Q1_C_test.txt'
data_train = readFile(training_file)
data_test = readFile(test_file)

# Train Inputs:
X_train = np.asarray([item[0] for item in data_train], dtype=float)
# Train Targets
y_train = np.asarray([item[1] for item in data_train], dtype=float)

# Test Inputs:
X_test = np.asarray([item[0] for item in data_test], dtype=float)
# Test Targets
y_test = np.asarray([item[1] for item in data_test], dtype=float)

assert X_train.shape==y_train.shape, "Shapes of Train Inputs and Train Targets are not matching..." 
assert X_test.shape==y_test.shape, "Shapes of Test Inputs and Test Targets are not matching..." 

if __name__ == "__main__":
    main()
    