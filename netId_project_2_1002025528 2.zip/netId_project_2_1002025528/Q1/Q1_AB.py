import numpy as np
import math
import matplotlib.pyplot as plt


# Removing "," and "(", ")" characters from the dataset
def clean_data(line):
    return line.replace('(', '').replace(')', '').replace(' ', '').strip().split(',')


# Retrieve data from the file
def fetch_data(filename):
    with open(filename, 'r') as f:
        input_data = f.readlines()
        clean_input = list(map(clean_data, input_data))
        f.close()
    return clean_input


# Reading file as a numpy array
def readFile(dataset_path):
    input_data = fetch_data(dataset_path)
    input_np = np.array(input_data)
    return input_np


# Function to generate plots for K and D
def genPlot(k_index, pItem):

	# Create Sine function plot using Matplotlib 
	figu = plt.figure()
	for index,item in enumerate(pItem):

		plt.plot(item["X"], item["Y"], '-o', label=str(index))
	plt.title("Trigometric Sine Funct for K ->  " + str(k_index+1))
	plt.scatter(X, y, color = '#77c999')
	plt.legend(loc='upper left')
	plt.xlabel('X-axis', fontsize=17,color="green")
	plt.ylabel('Y-axis', fontsize=17,color="green")

	#plt.savefig("Q1AB_K" + str(k_index+1) + ".png")
	plt.show()


# Linear Regression function with K and D values
def Linear_Regression(K=10, D=6):

	# Learning rate.
	L = 0.01
	
	# Defining the number of iterations.
	iterations=200
	
	# Number of Input samples in the dataset.
	n = X.shape[0]

	# Storing computed errors in the Matrix.

	errorMatrix = np.random.rand(K,D+1)

	# Stroring the computer Coefficients for the trignometric function in the Matrix.
	coefficientsMatrix = np.zeros((K,D+1), dtype=object)

	# Placeholder to generate plots on 'generatePlots' function call
	Single_PlotsKD = []

	# Iterate on 'K' values ranging from 1 to 10.
	k=1
	while(k<K+1):
		k_index = []

		print("For K = " + str(k))

		# Iterate on 'D' values ranging from 0 to 6.
		d=0
		while(d<(D+1)):
			val = -3
			increment = 0.1
			X1 = []
			Y1 = []
			

			# Place holder to store co-efficients Theta in linear regression.
			theta = np.zeros(d+1)

			# Place holder to store the predictions in linear regression.
			Y_pred = np.zeros(y.shape[0])
			
			for _ in range(61):
				val = val + increment
				val = round(val, 2)
				X1.append(val)


			# Regression model training.
			for _ in range(iterations):
				pointer = 0
				while(pointer<X.shape[0]):


					# Defining place holder for the function and the constant
					nonLinerEq = 0
					a0 = 1

					# Iterate over 'd' values to generate the function based on 'd' values.
					i = 0
					while(i<d+1):
						nonLinerEq = nonLinerEq + theta[i] * (math.sin(k * i * X[pointer]) * math.sin(k * i * X[pointer]))
						i = i + 1

					
					# Predction
					Y_pred[pointer] = a0 + nonLinerEq
					pointer+=1

				# Applying Gradient descent
				D_a0 = (-2/n) * sum(y - Y_pred)

				a0 -=  L * D_a0

				# Updating Theta values 
				j = 0

				while(j<len(theta)):

					D_theta = (-2/n) * sum(X * (y - Y_pred))
					theta[j] -= L * D_theta
					j+=1

		
			print("For d = " + str(d) + ' MSE = ' + str(round(np.square(y-Y_pred).mean(), 3)))
		
			
			X1_len = len(X1)
			x1 = 0
			while(x1<X1_len):
				nonLinerEq = 0
				
				for i in range(d+1):

					nonLinerEq += theta[i] * (math.sin(k * i * X1[x1]) * math.sin(k * i * X1[x1]))

				Y1.append(a0 + nonLinerEq)

				x1+=1


			# Save all mean squared error at every 'k' and 'd' values
			errorMatrix[k-1][d] = round(np.square(y-Y_pred).mean(), 3)

			# Save all co-efficients in the coefficientsMatrix
			coefficientsMatrix[k-1][d] = [a0] + list(theta)

			k_index.append({'X' : X1, 'Y' : Y1})

			d+=1

		Single_PlotsKD.append(k_index)

		k+=1
		

	# Generate plots 
	for k_index, k_plot in enumerate(Single_PlotsKD):

		genPlot(k_index, k_plot)

	k_best = np.where(errorMatrix==np.amin(errorMatrix))[0][0]+1
	d_best = np.where(errorMatrix==np.amin(errorMatrix))[1][0]
	
	
def main():
	print('START Q1_AB\n')
	'''
	Start writing your code here
	'''
	Linear_Regression()
	print('END Q1_AB\n')


loading_file = './datasets/Q1_B_train.txt'

data = readFile(loading_file)

# Inputs:
X = np.asarray([item[0] for item in data], dtype=float)

# Targets
y = np.asarray([item[1] for item in data], dtype=float)

assert X.shape==y.shape, "Shapes of Inputs and Targets are not matching..." 


if __name__ == "__main__":
    main()