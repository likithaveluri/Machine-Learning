#from pyexpat import ErrorString
import numpy as np
import math
import matplotlib.pyplot as plt


# Removing "," and "(", ")" characters from the dataset
def clean_data(line):
    return line.replace('(', '').replace(')', '').replace(' ', '').strip().split(',')


# Retrieve data from the file
def fetch_data(filename):
    with open(filename, 'r') as f:
        input_data = f.readlines()
        clean_input = list(map(clean_data, input_data))
        f.close()
    return clean_input


# Reading file as a numpy array
def readFile(dataset_path):
    input_data = fetch_data(dataset_path)
    input_np = np.array(input_data)
    return input_np


# Function to computer weighted matrix
def weighted_matrix(curr, X_temp): 

	# Tau for definfing the locality
	tau = 0.204

	# Initializing an identity matrix
	W = np.mat(np.eye(X_temp.shape[0]))

	# Denominator in the weighted average function
	denom = (-2 * tau * tau)

	# calculating the corresponding weights for a point
	i = 0

	while(i < X_temp.shape[0]):

		W[i,i] = np.exp(np.dot((X_temp[i]-curr), (X_temp[i]-curr).T)/denom)

		i += 1

	return W


def locallyWeightedLinearRegression():
	Y_pred = np.zeros(y_test.shape[0])

	errors = []

	pointer = 0

	while(pointer < X_test.shape[0]):

		# data (X + 1)
		X_temp = np.append(X_train.reshape(X_train.shape[0],1), np.ones(X_train.shape[0]).reshape(X_train.shape[0],1), axis=1)

		# Current datapoint from the test set 
		curr = np.array([X_test[pointer], 1])

		# Updating the values for weighted matrix 
		W = weighted_matrix(curr, X_temp)

		# Calculating for theta
		theta = np.linalg.pinv(X_temp.T*(W * X_temp))*(X_temp.T*(W * y_train.reshape(y_train.shape[0],1)))

		# applying regression for prediction
		Y_pred[pointer] = np.dot(curr, theta)

		# Error calculation
		error = (Y_pred[pointer] - y_test[pointer]) ** 2

		errors.append(error)

		pointer += 1
	
	print("Data Size: " + str(X_train.shape[0]) + ", MSE:", round(np.mean(errors), 6))

	
	
	# Plot for training datapoints and the locally weighted regression function
	plt.scatter(X_test, y_test, label='Test data 10 points')
	plt.scatter(X_train, y_train, label='Train data 20 points')
	plt.title("Locally Weighted Linear Regression")
	plt.legend(loc='upper left')
	plt.grid()
	#plt.savefig("Q2_DFunctionGraphWithError.png")
	plt.show()
	
	


def main():
	print('START Q2_D\n')
	'''
	Start writing your code here
	'''
	locallyWeightedLinearRegression()
	print('END Q2_D\n')


training_file = './datasets/Q1_B_train.txt'
test_file = './datasets/Q1_C_test.txt'
training_data = readFile(training_file)
test_data = readFile(test_file)
# Inputs of train (Considering only first 20 elements from the training set)
X_train = np.asarray([item[0] for item in training_data[:20]], dtype=float)

# Inputs of test
X_test = np.asarray([item[0] for item in test_data], dtype=float)

# Targets of train (Considering only first 20 elements from the training set)
y_train= np.asarray([item[1] for item in training_data[:20]], dtype=float)

# Targets of test
y_test= np.asarray([item[1] for item in test_data], dtype=float)

assert X_train.shape==y_train.shape, "Shapes of Inputs and Targets on training set are not matching..." 
assert X_test.shape==y_test.shape, "Shapes of Inputs and Targets on test set are not matching..." 


if __name__ == "__main__":
    main()
    